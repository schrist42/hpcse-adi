var searchData=
[
  ['diagonals_20of_20the_20tridiagonal_20matrix_2e',['Diagonals of the tridiagonal matrix.',['../group__Diagonals.html',1,'']]]
];
