var searchData=
[
  ['getl',['getL',['../group__getdiagonals.html#ga1fc79c48a0e508670d9cb446bdb89ac0',1,'TriDiagMatrix']]],
  ['getm',['getM',['../group__getdiagonals.html#gaef21cbb3555650842cc666112732110e',1,'TriDiagMatrix']]],
  ['getu',['getU',['../group__getdiagonals.html#ga23e779914d8691b0b9012c4f45e036ca',1,'TriDiagMatrix']]],
  ['grayscott',['GrayScott',['../classGrayScott.html#aea6ca9ee2a59a337730a787c400a858d',1,'GrayScott']]],
  ['gsviewer',['GSViewer',['../classGSViewer.html#ab88d43b4279ded01eff0a896a10dad4e',1,'GSViewer']]]
];
