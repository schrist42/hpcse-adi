var searchData=
[
  ['run',['run',['../classGrayScott.html#adf11a6024de7c77b1e1aae00fa78d174',1,'GrayScott']]]
];
