var searchData=
[
  ['tridiagmatrix',['TriDiagMatrix',['../classTriDiagMatrix.html#a089010de74d434cd0c9ca33f9421b898',1,'TriDiagMatrix::TriDiagMatrix()'],['../classTriDiagMatrix.html#a566110e41f5c7d507ad1bff5e4d3b741',1,'TriDiagMatrix::TriDiagMatrix(int N, double l, double m, double u)']]]
];
