var searchData=
[
  ['return_20the_20diagonals_2e',['Return the diagonals.',['../group__getdiagonals.html',1,'']]]
];
