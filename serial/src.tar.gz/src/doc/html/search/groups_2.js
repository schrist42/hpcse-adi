var searchData=
[
  ['tridiagonal_20matrices_2e',['Tridiagonal matrices.',['../group__matrices.html',1,'']]]
];
